import React, { Component, PropTypes } from 'react';

class CustomPlayer extends Component {
  render() {
    return (
      <div />
    );
  }
}

CustomPlayer.propTypes = {

};

export default CustomPlayer;
