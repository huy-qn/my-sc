import React, { Component, PropTypes } from 'react';
import { SoundPlayerContainer } from 'react-soundplayer/addons';

const styles = {
  listItem: 'bg-white tl',
  activeListItem: 'bg-black white tl',
};

class Player extends Component {
  constructor() {
    super();

    this.state = {
      activeIndex: 0,
    };
  }

  playThisIndex = (playlistIndex) => {
    const { soundCloudAudio } = this.props;
    this.setState({ activeIndex: playlistIndex });
    soundCloudAudio.play({ playlistIndex });
  }

  nextIndex = () => {
    let { activeIndex } = this.state;
    const { playlist, soundCloudAudio } = this.props;
    if (activeIndex >= playlist.tracks.length - 1) {
      return;
    }
    if (activeIndex || activeIndex === 0) {
      this.setState({ activeIndex: ++activeIndex });
    }
    soundCloudAudio.play({ playlistIndex: activeIndex });
  }

  prevIndex = () => {
    let { activeIndex } = this.state;
    const { soundCloudAudio } = this.props;
    if (activeIndex <= 0) {
      return;
    }
    if (activeIndex || activeIndex === 0) {
      this.setState({ activeIndex: --activeIndex });
    }
    soundCloudAudio.play({ playlistIndex: activeIndex });
  }

  play = () => {
    const { soundCloudAudio, playing } = this.props;
    const { activeIndex } = this.state;
    if (playing) {
      soundCloudAudio.pause();
    } else {
      soundCloudAudio.play({ playlistIndex: activeIndex });
    }
  }

  renderTrackList = () => {
    const { playlist } = this.props;

    if (!playlist) {
      return <span>loading</span>;
    }

    const tracks = playlist.tracks.map((track, i) => {
      return (
        <a onClick={() => this.playThisIndex(i)}><li
          key={track.id}
          className={
            (this.state.activeIndex === i)
            ? `${styles.activeListItem}` : `${styles.listItem}`}
        >
          <span>{track.title}</span>
        </li></a>
      );
    });

    return (
      <div>{tracks}</div>
    );
  }

  renderCurrentCover = () => {
    const { playlist } = this.props;

    if (!playlist) {
      return <span>loading</span>;
    }

    const { activeIndex } = this.state;
    const currentSong = playlist.tracks[activeIndex];
    const currentCover = playlist.tracks[activeIndex].artwork_url;
    const defaultCover = 'https://storage.jumpshare.com/preview/3wAgsOnuQggLm3L2klTMqSCGEMROFYyQXpubcAP5dek7u3nl3RXhDrvFq_G232K02t_7D358FE_49xCu167Mg1NlSmh0egFbdyHzE6LvoMAI4av1wcwKsmUDuTGzHRrg';

    return (
      <img src={currentCover || defaultCover} alt={currentSong.description} />
    );
  }


  render() {
    const { playing } = this.props;
    return (
      <div>
        {this.renderCurrentCover()}
        <button onClick={() => this.play()}>{playing ? 'Pause' : 'Play'}</button>
        <button onClick={() => this.prevIndex()}>Prev</button>
        <button onClick={() => this.nextIndex()}>Next</button>
        {this.renderTrackList()}
      </div>
    );
  }
}

class Playlist extends Component {
  render() {
    return (
      <SoundPlayerContainer
        clientId={this.props.clientId}
        resolveUrl={this.props.resolveUrl}
      >
        <Player />
      </SoundPlayerContainer>
    );
  }
}

Playlist.propTypes = {

};

export default Playlist;
